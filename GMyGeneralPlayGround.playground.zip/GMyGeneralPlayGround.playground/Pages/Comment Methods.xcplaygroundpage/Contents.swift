import UIKit
import MapKit
import AVFoundation
//var greeting = "Hello, playground"

/// comments in swift
// first way to write one line comment uses "//"
// swcond to write multi-lines comments use at
//first "*/" then at the last of comments use "*\"
// third way caled maghraby multilie comments by
//using "///" and this way every line would be comment uless to turn to "//




