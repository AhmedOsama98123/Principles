//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)

var name = "ahmed"   // string Variables
//types of data
/*
 1- strings  for writing
 2- Int for interges thar are number
 3-float === decimal number
 4- double == large decemal number 15 number
 boalian == true or false
 
 */

//multiple implemantaion

var name1 = "ahmed", second_name = "Osama"

//constant implemantaion

let number = 15
let numberInDouble = 3.18744

print(number)
print(numberInDouble)
// boalian variable
var hasnumber = true


